from aiogram import Router, F
from aiogram.types import CallbackQuery

from db.database import get_top_vaimiki, get_top_crop
from keyboards.inline import tops_kb, back_to_tops_kb
from config import CROPS, CURRENCY, CURRENCY_EMOJI

router = Router()


@router.callback_query(F.data == "tops")
async def cb_tops(callback: CallbackQuery):
    text = (
        "🏆 <b>Топы фермеров</b>\n\n"
        "Выбери категорию:\n"
        "• Глобальный топ по Ваймикам\n"
        "• Отдельные топы по каждой культуре (сколько собрано всего)"
    )
    await callback.message.edit_text(text, reply_markup=tops_kb(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("top:"))
async def cb_top(callback: CallbackQuery):
    key = callback.data.split(":")[1]

    if key == "vaimiki":
        top = await get_top_vaimiki(10)
        title = f"💎 <b>Топ по {CURRENCY}</b>"
        lines = [title, ""]
        if not top:
            lines.append("Пока никого нет :(")
        else:
            for i, u in enumerate(top, 1):
                name = u["full_name"] or u["username"] or f"ID{u['user_id']}"
                medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
                lines.append(f"{medal} {name} — <b>{u['vaimiki']}</b> {CURRENCY_EMOJI}")
    else:
        if key not in CROPS:
            await callback.answer("Неизвестная культура", show_alert=True)
            return
        name, emoji, *_ = CROPS[key]
        top = await get_top_crop(key, 10)
        title = f"{emoji} <b>Топ по {name}</b> (собрано всего)"
        lines = [title, ""]
        if not top:
            lines.append("Пока никого нет :(")
        else:
            for i, u in enumerate(top, 1):
                uname = u["full_name"] or u["username"] or f"ID{u['user_id']}"
                medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
                lines.append(f"{medal} {uname} — <b>{u['harvested']}</b> шт")

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=back_to_tops_kb(),
        parse_mode="HTML"
    )
    await callback.answer()
