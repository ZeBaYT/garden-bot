import time
from aiogram import Router, F
from aiogram.types import CallbackQuery

from db.database import (
    ensure_user, get_user, get_inventory, get_plots,
    count_active_plots, plant, harvest_all
)
from keyboards.inline import farm_kb, plant_menu_kb, plant_amount_kb, main_menu_kb
from config import CROPS, CURRENCY, CURRENCY_EMOJI, MAX_PLOTS

router = Router()


def format_time_left(seconds: float) -> str:
    if seconds <= 0:
        return "✅ Готово!"
    mins = int(seconds // 60)
    secs = int(seconds % 60)
    if mins > 60:
        hours = mins // 60
        mins = mins % 60
        return f"{hours}ч {mins}м"
    return f"{mins}м {secs}с"


@router.callback_query(F.data == "farm")
async def cb_farm(callback: CallbackQuery):
    await ensure_user(callback.from_user.id, callback.from_user.username, callback.from_user.full_name)
    plots = await get_plots(callback.from_user.id)
    now = time.time()

    lines = [f"🌾 <b>Твоя ферма</b>\n"]
    if not plots:
        lines.append("Грядки пустые. Посади что-нибудь!")
    else:
        ready_count = 0
        for i, p in enumerate(plots, 1):
            crop = p["crop_key"]
            name, emoji, *_ = CROPS[crop]
            left = p["ready_at"] - now
            status = format_time_left(left)
            if left <= 0:
                ready_count += 1
            lines.append(f"{i}. {emoji} {name} — {status}")
        lines.append(f"\nАктивных грядок: {len(plots)}/{MAX_PLOTS}")
        if ready_count:
            lines.append(f"🎉 Готово к сбору: <b>{ready_count}</b>")

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=farm_kb(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "plant_menu")
async def cb_plant_menu(callback: CallbackQuery):
    inv = await get_inventory(callback.from_user.id)
    active = await count_active_plots(callback.from_user.id)
    text = (
        f"🌱 <b>Посадка</b>\n\n"
        f"Свободных грядок: <b>{MAX_PLOTS - active}</b>\n"
        f"Выбери культуру:"
    )
    await callback.message.edit_text(text, reply_markup=plant_menu_kb(inv), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("plant_crop:"))
async def cb_plant_crop(callback: CallbackQuery):
    crop_key = callback.data.split(":")[1]
    if crop_key not in CROPS:
        await callback.answer("Неизвестная культура", show_alert=True)
        return

    inv = await get_inventory(callback.from_user.id)
    seeds = inv.get(crop_key, {}).get("seeds", 0)
    active = await count_active_plots(callback.from_user.id)
    free = MAX_PLOTS - active
    max_can = min(seeds, free)

    name, emoji, value, grow_sec, ymin, ymax = CROPS[crop_key]
    mins = grow_sec // 60

    if max_can <= 0:
        await callback.answer(
            "Нет семян или нет свободных грядок!" if seeds == 0 else "Нет свободных грядок!",
            show_alert=True
        )
        return

    text = (
        f"{emoji} <b>{name}</b>\n"
        f"Рост: {mins} мин\n"
        f"Урожай с 1 семени: {ymin}–{ymax} шт\n"
        f"Цена 1 шт урожая: {value} {CURRENCY_EMOJI}\n\n"
        f"Семян у тебя: {seeds}\n"
        f"Свободных грядок: {free}\n\n"
        f"Сколько посадить?"
    )
    await callback.message.edit_text(
        text,
        reply_markup=plant_amount_kb(crop_key, max_can),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("do_plant:"))
async def cb_do_plant(callback: CallbackQuery):
    parts = callback.data.split(":")
    crop_key = parts[1]
    amount = int(parts[2])

    ok = await plant(callback.from_user.id, crop_key, amount)
    if not ok:
        await callback.answer("Не удалось посадить (мало семян / грядок)", show_alert=True)
        return

    name, emoji, *_ = CROPS[crop_key]
    await callback.answer(f"Посажено {amount} × {emoji} {name}!", show_alert=True)

    # возвращаем на ферму
    plots = await get_plots(callback.from_user.id)
    now = time.time()
    lines = [f"🌾 <b>Твоя ферма</b>\n"]
    for i, p in enumerate(plots, 1):
        c = p["crop_key"]
        n, e, *_ = CROPS[c]
        left = p["ready_at"] - now
        lines.append(f"{i}. {e} {n} — {format_time_left(left)}")
    lines.append(f"\nАктивных грядок: {len(plots)}/{MAX_PLOTS}")

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=farm_kb(),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "harvest")
async def cb_harvest(callback: CallbackQuery):
    result = await harvest_all(callback.from_user.id)

    if result["total_crops"] == 0:
        await callback.answer("Пока нечего собирать 🌱", show_alert=True)
        return

    lines = [f"🧺 <b>Урожай собран!</b>\n"]
    for crop, amount in result["harvested"].items():
        name, emoji, value, *_ = CROPS[crop]
        lines.append(f"{emoji} {name}: +{amount} шт (+{amount * value} {CURRENCY_EMOJI})")
    lines.append(f"\n💰 Получено: <b>+{result['vaimiki_gained']} {CURRENCY}</b>")

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=farm_kb(),
        parse_mode="HTML"
    )
    await callback.answer("Урожай в кармане!")
