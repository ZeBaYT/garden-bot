from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command

from db.database import ensure_user, get_user, get_inventory
from keyboards.inline import main_menu_kb, back_main_kb
from config import CURRENCY, CURRENCY_EMOJI, CROPS

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    await ensure_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.full_name
    )
    text = (
        f"🌾 <b>Добро пожаловать на Ферму Ваймиков!</b>\n\n"
        f"Здесь ты выращиваешь овощи и зарабатываешь {CURRENCY_EMOJI} <b>{CURRENCY}</b>.\n\n"
        f"• Сажай семена\n"
        f"• Жди пока вырастут (от 30 минут)\n"
        f"• Собирай урожай и получай {CURRENCY}\n"
        f"• Соревнуйся в топах!\n\n"
        f"Нажми кнопку ниже, чтобы начать 👇"
    )
    await message.answer(text, reply_markup=main_menu_kb(), parse_mode="HTML")


@router.callback_query(F.data == "main_menu")
async def cb_main_menu(callback: CallbackQuery):
    await callback.message.edit_text(
        "🏠 <b>Главное меню</b>\n\nВыбери действие:",
        reply_markup=main_menu_kb(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "profile")
async def cb_profile(callback: CallbackQuery):
    user = await get_user(callback.from_user.id)
    inv = await get_inventory(callback.from_user.id)

    lines = [
        f"👤 <b>Профиль</b>",
        f"Имя: {callback.from_user.full_name}",
        f"{CURRENCY_EMOJI} {CURRENCY}: <b>{user['vaimiki']}</b>",
        "",
        "📦 <b>Инвентарь:</b>"
    ]
    for key, (name, emoji, *_) in CROPS.items():
        data = inv.get(key, {"seeds": 0, "harvested": 0})
        lines.append(f"{emoji} {name}: семян {data['seeds']} | собрано {data['harvested']}")

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=back_main_kb(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "help")
async def cb_help(callback: CallbackQuery):
    text = (
        f"ℹ️ <b>Как играть</b>\n\n"
        f"1. Зайди в <b>Магазин семян</b> и купи семена за {CURRENCY}.\n"
        f"2. Перейди в <b>Моя ферма</b> → Посадить.\n"
        f"3. Выбери культуру и количество.\n"
        f"4. Жди (время роста указано у каждой культуры).\n"
        f"5. Нажми <b>Собрать урожай</b> — получишь овощи + {CURRENCY}!\n\n"
        f"<b>Цены за 1 единицу урожая:</b>\n"
    )
    for key, (name, emoji, value, grow_sec, ymin, ymax) in CROPS.items():
        mins = grow_sec // 60
        text += f"{emoji} {name}: {value} {CURRENCY_EMOJI} | рост {mins} мин | урожай {ymin}–{ymax}\n"

    text += (
        f"\nУ тебя максимум 5 активных грядок одновременно.\n"
        f"Семена стоят в 2 раза дороже, чем даёт урожай — выгода в количестве!"
    )
    await callback.message.edit_text(text, reply_markup=back_main_kb(), parse_mode="HTML")
    await callback.answer()
