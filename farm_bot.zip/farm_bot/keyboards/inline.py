from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from config import CROPS, CURRENCY_EMOJI


def main_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🌾 Моя ферма", callback_data="farm"),
        InlineKeyboardButton(text="👤 Профиль", callback_data="profile"),
    )
    builder.row(
        InlineKeyboardButton(text="🛒 Магазин семян", callback_data="shop"),
        InlineKeyboardButton(text="🏆 Топы", callback_data="tops"),
    )
    builder.row(
        InlineKeyboardButton(text="ℹ️ Помощь", callback_data="help"),
    )
    return builder.as_markup()


def farm_kb(has_ready: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🌱 Посадить", callback_data="plant_menu"),
        InlineKeyboardButton(text="🧺 Собрать урожай", callback_data="harvest"),
    )
    builder.row(
        InlineKeyboardButton(text="🔄 Обновить", callback_data="farm"),
        InlineKeyboardButton(text="◀️ Назад", callback_data="main_menu"),
    )
    return builder.as_markup()


def plant_menu_kb(inventory: dict) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for key, (name, emoji, *_) in CROPS.items():
        seeds = inventory.get(key, {}).get("seeds", 0)
        builder.row(
            InlineKeyboardButton(
                text=f"{emoji} {name} (семян: {seeds})",
                callback_data=f"plant_crop:{key}"
            )
        )
    builder.row(InlineKeyboardButton(text="◀️ Назад", callback_data="farm"))
    return builder.as_markup()


def plant_amount_kb(crop_key: str, max_amount: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    amounts = [1, 2, 3, 5]
    row = []
    for a in amounts:
        if a <= max_amount:
            row.append(InlineKeyboardButton(text=str(a), callback_data=f"do_plant:{crop_key}:{a}"))
    if row:
        builder.row(*row)
    if max_amount > 5:
        builder.row(InlineKeyboardButton(text=f"Все ({max_amount})", callback_data=f"do_plant:{crop_key}:{max_amount}"))
    builder.row(InlineKeyboardButton(text="◀️ Назад", callback_data="plant_menu"))
    return builder.as_markup()


def shop_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for key, (name, emoji, value, *_) in CROPS.items():
        price = value * 2
        builder.row(
            InlineKeyboardButton(
                text=f"{emoji} {name} — {price} {CURRENCY_EMOJI} / шт",
                callback_data=f"buy_seed:{key}"
            )
        )
    builder.row(InlineKeyboardButton(text="◀️ Назад", callback_data="main_menu"))
    return builder.as_markup()


def buy_amount_kb(crop_key: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for a in [1, 3, 5, 10]:
        builder.add(InlineKeyboardButton(text=str(a), callback_data=f"do_buy:{crop_key}:{a}"))
    builder.adjust(4)
    builder.row(InlineKeyboardButton(text="◀️ Назад", callback_data="shop"))
    return builder.as_markup()


def tops_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text=f"💎 Топ по Ваймикам", callback_data="top:vaimiki"),
    )
    builder.row(
        InlineKeyboardButton(text="🥕 Морковь", callback_data="top:carrot"),
        InlineKeyboardButton(text="🟣 Свёкла", callback_data="top:beet"),
    )
    builder.row(
        InlineKeyboardButton(text="🥔 Картошка", callback_data="top:potato"),
        InlineKeyboardButton(text="🍅 Помидор", callback_data="top:tomato"),
    )
    builder.row(
        InlineKeyboardButton(text="🥬 Капуста", callback_data="top:cabbage"),
        InlineKeyboardButton(text="🌽 Кукуруза", callback_data="top:corn"),
    )
    builder.row(InlineKeyboardButton(text="◀️ Назад", callback_data="main_menu"))
    return builder.as_markup()


def back_to_tops_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="◀️ К топам", callback_data="tops"))
    builder.row(InlineKeyboardButton(text="🏠 Главное меню", callback_data="main_menu"))
    return builder.as_markup()


def back_main_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="◀️ Главное меню", callback_data="main_menu"))
    return builder.as_markup()
