import aiosqlite
import time
from typing import Optional, List, Dict, Any
from config import CROPS, START_VAIMIKI, START_SEEDS, MAX_PLOTS

DB_PATH = "farm.db"


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                vaimiki INTEGER DEFAULT 0,
                created_at REAL
            )
        """)
        # Инвентарь семян и собранного урожая
        await db.execute("""
            CREATE TABLE IF NOT EXISTS inventory (
                user_id INTEGER,
                crop_key TEXT,
                seeds INTEGER DEFAULT 0,
                harvested INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, crop_key)
            )
        """)
        # Активные посадки
        await db.execute("""
            CREATE TABLE IF NOT EXISTS plots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                crop_key TEXT,
                amount INTEGER,
                planted_at REAL,
                ready_at REAL
            )
        """)
        await db.commit()


async def ensure_user(user_id: int, username: str = None, full_name: str = None):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT user_id FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        if not row:
            await db.execute(
                "INSERT INTO users (user_id, username, full_name, vaimiki, created_at) VALUES (?, ?, ?, ?, ?)",
                (user_id, username or "", full_name or "", START_VAIMIKI, time.time())
            )
            for crop, amount in START_SEEDS.items():
                await db.execute(
                    "INSERT INTO inventory (user_id, crop_key, seeds, harvested) VALUES (?, ?, ?, 0)",
                    (user_id, crop, amount)
                )
            # остальные культуры с 0
            for crop in CROPS:
                if crop not in START_SEEDS:
                    await db.execute(
                        "INSERT INTO inventory (user_id, crop_key, seeds, harvested) VALUES (?, ?, 0, 0)",
                        (user_id, crop)
                    )
            await db.commit()
        else:
            # обновить имя если изменилось
            await db.execute(
                "UPDATE users SET username = ?, full_name = ? WHERE user_id = ?",
                (username or "", full_name or "", user_id)
            )
            await db.commit()


async def get_user(user_id: int) -> Optional[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        return dict(row) if row else None


async def get_inventory(user_id: int) -> Dict[str, Dict[str, int]]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT crop_key, seeds, harvested FROM inventory WHERE user_id = ?", (user_id,)
        )
        rows = await cursor.fetchall()
        result = {crop: {"seeds": 0, "harvested": 0} for crop in CROPS}
        for row in rows:
            result[row["crop_key"]] = {"seeds": row["seeds"], "harvested": row["harvested"]}
        return result


async def get_plots(user_id: int) -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM plots WHERE user_id = ? ORDER BY planted_at", (user_id,)
        )
        rows = await cursor.fetchall()
        return [dict(r) for r in rows]


async def count_active_plots(user_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT COUNT(*) FROM plots WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        return row[0] if row else 0


async def plant(user_id: int, crop_key: str, amount: int) -> bool:
    """Посадить amount семян. Возвращает True если успешно."""
    if crop_key not in CROPS:
        return False
    inv = await get_inventory(user_id)
    if inv[crop_key]["seeds"] < amount:
        return False
    if await count_active_plots(user_id) + amount > MAX_PLOTS:
        return False

    name, emoji, value, grow_time, ymin, ymax = CROPS[crop_key]
    now = time.time()
    ready = now + grow_time

    async with aiosqlite.connect(DB_PATH) as db:
        # списываем семена
        await db.execute(
            "UPDATE inventory SET seeds = seeds - ? WHERE user_id = ? AND crop_key = ?",
            (amount, user_id, crop_key)
        )
        # создаём грядки (по одной на каждое семя для простоты, или одну запись)
        for _ in range(amount):
            await db.execute(
                "INSERT INTO plots (user_id, crop_key, amount, planted_at, ready_at) VALUES (?, ?, 1, ?, ?)",
                (user_id, crop_key, now, ready)
            )
        await db.commit()
    return True


async def harvest_all(user_id: int) -> Dict[str, Any]:
    """Собрать всё готовое. Возвращает dict с результатами."""
    now = time.time()
    plots = await get_plots(user_id)
    ready_plots = [p for p in plots if p["ready_at"] <= now]

    if not ready_plots:
        return {"harvested": {}, "vaimiki_gained": 0, "total_crops": 0}

    from random import randint
    harvested = {}
    total_vaimiki = 0
    total_crops = 0
    ids_to_delete = []

    for p in ready_plots:
        crop = p["crop_key"]
        name, emoji, value, _, ymin, ymax = CROPS[crop]
        amount = randint(ymin, ymax)
        harvested[crop] = harvested.get(crop, 0) + amount
        total_vaimiki += amount * value
        total_crops += amount
        ids_to_delete.append(p["id"])

    async with aiosqlite.connect(DB_PATH) as db:
        # удаляем грядки
        for pid in ids_to_delete:
            await db.execute("DELETE FROM plots WHERE id = ?", (pid,))
        # добавляем в инвентарь harvested и ваймики
        for crop, amount in harvested.items():
            await db.execute(
                "UPDATE inventory SET harvested = harvested + ? WHERE user_id = ? AND crop_key = ?",
                (amount, user_id, crop)
            )
        await db.execute(
            "UPDATE users SET vaimiki = vaimiki + ? WHERE user_id = ?",
            (total_vaimiki, user_id)
        )
        await db.commit()

    return {
        "harvested": harvested,
        "vaimiki_gained": total_vaimiki,
        "total_crops": total_crops
    }


async def buy_seeds(user_id: int, crop_key: str, amount: int) -> bool:
    """Купить семена. Цена = value * 2 * amount (чтобы был смысл растить)."""
    if crop_key not in CROPS:
        return False
    _, _, value, *_ = CROPS[crop_key]
    cost = value * 2 * amount

    user = await get_user(user_id)
    if not user or user["vaimiki"] < cost:
        return False

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET vaimiki = vaimiki - ? WHERE user_id = ?",
            (cost, user_id)
        )
        # убедимся что запись есть
        await db.execute(
            "INSERT OR IGNORE INTO inventory (user_id, crop_key, seeds, harvested) VALUES (?, ?, 0, 0)",
            (user_id, crop_key)
        )
        await db.execute(
            "UPDATE inventory SET seeds = seeds + ? WHERE user_id = ? AND crop_key = ?",
            (amount, user_id, crop_key)
        )
        await db.commit()
    return True


async def get_top_vaimiki(limit: int = 10) -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT user_id, username, full_name, vaimiki FROM users ORDER BY vaimiki DESC LIMIT ?",
            (limit,)
        )
        return [dict(r) for r in await cursor.fetchall()]


async def get_top_crop(crop_key: str, limit: int = 10) -> List[Dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("""
            SELECT u.user_id, u.username, u.full_name, i.harvested
            FROM inventory i
            JOIN users u ON u.user_id = i.user_id
            WHERE i.crop_key = ?
            ORDER BY i.harvested DESC
            LIMIT ?
        """, (crop_key, limit))
        return [dict(r) for r in await cursor.fetchall()]
