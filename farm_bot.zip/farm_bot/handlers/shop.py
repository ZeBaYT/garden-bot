from aiogram import Router, F
from aiogram.types import CallbackQuery

from db.database import ensure_user, get_user, buy_seeds
from keyboards.inline import shop_kb, buy_amount_kb, main_menu_kb
from config import CROPS, CURRENCY, CURRENCY_EMOJI

router = Router()


@router.callback_query(F.data == "shop")
async def cb_shop(callback: CallbackQuery):
    await ensure_user(callback.from_user.id, callback.from_user.username, callback.from_user.full_name)
    user = await get_user(callback.from_user.id)
    text = (
        f"🛒 <b>Магазин семян</b>\n\n"
        f"У тебя: {CURRENCY_EMOJI} <b>{user['vaimiki']}</b> {CURRENCY}\n\n"
        f"Цена семян = 2 × стоимость урожая.\n"
        f"Выбери культуру:"
    )
    await callback.message.edit_text(text, reply_markup=shop_kb(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("buy_seed:"))
async def cb_buy_seed(callback: CallbackQuery):
    crop_key = callback.data.split(":")[1]
    if crop_key not in CROPS:
        await callback.answer("Неизвестная культура", show_alert=True)
        return

    name, emoji, value, *_ = CROPS[crop_key]
    price = value * 2
    text = (
        f"{emoji} <b>{name}</b>\n"
        f"Цена 1 семени: {price} {CURRENCY_EMOJI}\n\n"
        f"Сколько купить?"
    )
    await callback.message.edit_text(
        text,
        reply_markup=buy_amount_kb(crop_key),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("do_buy:"))
async def cb_do_buy(callback: CallbackQuery):
    parts = callback.data.split(":")
    crop_key = parts[1]
    amount = int(parts[2])

    ok = await buy_seeds(callback.from_user.id, crop_key, amount)
    if not ok:
        await callback.answer("Недостаточно Ваймиков!", show_alert=True)
        return

    name, emoji, value, *_ = CROPS[crop_key]
    cost = value * 2 * amount
    user = await get_user(callback.from_user.id)

    await callback.answer(f"Куплено {amount} × {emoji} {name} за {cost}!", show_alert=True)

    text = (
        f"🛒 <b>Магазин семян</b>\n\n"
        f"У тебя: {CURRENCY_EMOJI} <b>{user['vaimiki']}</b> {CURRENCY}\n\n"
        f"✅ Успешная покупка!\nВыбери ещё или вернись назад:"
    )
    await callback.message.edit_text(text, reply_markup=shop_kb(), parse_mode="HTML")
